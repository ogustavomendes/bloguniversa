<?php

$config = [
	'name' => __('Socials', 'blocksy'),
	'clone' => true,
	'selective_refresh' => [
		'footerSocialsColor'
	],
];

