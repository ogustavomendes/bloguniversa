<?php

$config = [
	'name' => __('Footer Menu', 'blocksy'),
	'typography_keys' => ['footerMenuFont'],
	'selective_refresh' => ['menu']
];

