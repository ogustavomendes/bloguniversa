<?php

$config = [
	'name' => __('Main Row', 'blocksy')
];


