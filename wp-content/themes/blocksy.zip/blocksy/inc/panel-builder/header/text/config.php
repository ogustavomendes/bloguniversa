<?php

$config = [
	'name' => __('HTML', 'blocksy'),
	'typography_keys' => ['headerTextFont'],
	'clone' => true,

	'translation_keys' => [
		[
			'key' => 'header_text',
			'multiline' => true
		]
	]
];
