__webpack_public_path__ =
	ct_customizer_localizations.static_public_url + 'bundle/'
